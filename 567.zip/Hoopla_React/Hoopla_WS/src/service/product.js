const dbLayer = require('../model/product');

product = {}

product.setupDB = () => {
   return dbLayer.setupDB().then( response => {  
    if(response){
        return response;
       }else{
           let err = new Error('Insertion Failed');
           err.status = 500;
          throw err;
       } 
   });
}
product.getAllProducts = () => {
    return dbLayer.getAllProducts().then( response => {
        return response
    })
}
product.getCategoryProducts = (category) => {
    return dbLayer.getCategoryProducts(category).then( response => {
        return response
    })
}
product.searchedProduct = (searchedData) => {
    return dbLayer.searchedProduct(searchedData).then( response => {
        return response
    })
}
module.exports=product;