const { Schema } = require('mongoose');
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
const url = "mongodb://localhost:27017/Hoopla_DB"

const usersSchema = Schema({
    userId : {type : String, required : [true, 'userId is required']},
    uCredentials : {
        uEmail : {type : String, required : [true, 'uMail is required']},
        uPass  : {type : String, required : [true, 'uPass is required']}
    },
    uProfile : {
        uName : {type : String, required : [true, 'uName is required']},
        uDOB : {type : Date, required : [true, 'uDOB is required']},
        uPhone : {type : Number, required : [true, 'uPhone is required']},
        uDateJoined : {type : Date, default : new Date().toISOString()},
        uLastLogin : {type : Date, default : new Date().toISOString()}
    }
}, {collection : "Users", timestamps: true })

const productSchema=Schema({
    _id:{type : String, required : [true, 'userId is required']},
    pName:{type : String, required : [true, 'pName is required']},
    pDescription:{type : String, required : [true, 'description is required']},
    pRating:{type:Number},
    pCategory:{type : String, required : [true, 'category is required']},
    price:{type : String, required : [true, 'price is required']},
    color:{type : String, required : [true, 'color is required']},
    image:{type : String, required : [true, 'imageName is required']},
    specification:{type : String},
    dateFirstAvailable:{
        date:{type : Date, default : new Date().toISOString()}
    },
    dateLastAvailable:{
        date:{type : Date, default : new Date().toISOString()}
    },
    pSeller:{
        s_Id:{type : String, required : [true, 'userId is required']},
        pDiscount:{type:Number},
        pQuantity:{type : Number, required : [true, 'quantity is required']},
        pShippingCharges:{type:Number}
    }
},{collection:"Products"})

let connection = {}

//Returns model object of "Users" collection
connection.getCollection = () => {
    //establish connection and return model as promise
    return mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex : true}).then( database => {
        return database.model('Users', usersSchema)
    }).catch( error => {
        let err = new Error("Could not connect to the user database");
        err.status = 500;
        throw err;
    });
}
connection.getProductCollection = () => {
    return mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex : true} ).then((database)=>{
        return database.model("Products", productSchema)
    }).catch( error =>{
        let err = new Error("Could not connect to the product database");
        err.status = 500;
        throw err; 
    })
}

module.exports = connection;