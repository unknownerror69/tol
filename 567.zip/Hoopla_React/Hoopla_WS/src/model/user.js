const collection = require('../utilities/connection');
const userData = require('./User.json');
let user = {}

//Setup the database
user.setupDB = () => {
   return collection.getCollection().then( userColl => {
       return userColl.deleteMany().then( data => {
           return userColl.insertMany(userData).then( result => {
               if( result && result.length > 0 ) return result.length
               else return null
           });
       });
   });
}
user.generateId = () => {
    return collection.getCollection().then((model) => {
        return model.distinct("userId").then((ids) => {
            let lastId=ids[ids.length-1]
            lastId=lastId.slice(1)
            let num=parseInt(lastId,10)+1
            console.log(num)
            let x="U"+num
            //console.log(lastId,x)
            return x
        })
    })
}

//Verify the user credentials and modify the last logout
user.userLogin = (uEmail,uPass) => {
    return collection.getCollection().then( userColl => {
        return userColl.findOne({"uCredentials.uEmail" : uEmail}).then( data => {
            if(data){
                if( uPass == data['uCredentials']['uPass']){
                    return userColl.updateOne({"uCredentials.uEmail":uEmail},{$set:{"uProfile.uLastLogin":new Date().toISOString()}}).then( res => {
                        if(res.nModified === 1){
                            console.log("pass")
                            return data
                        }
                    })
                }else{
                    throw new Error("The password entered is incorrect!!")
                }
            }else{
                throw new Error("You are not registered.Please register to login"); 
            }
        })
    }) 
    
}
//register user
user.userRegister = (uData) => {
    return collection.getCollection().then( userColl => {
        return user.generateId().then((id)=>{
            uData.userId=id
        return userColl.create(
            {   
                "userId":uData.userId,
                "uCredentials" : {
                    "uEmail" : uData.uEmail,
                    "uPass" : uData.uPass
                },
                "uProfile" : {
                    "uName" : uData.uName,
                    "uDOB" : uData.uDOB,
                    "uPhone" : uData.uPhone,
                }
            }
        ).then( data => {
            
            if(data){
                return data
            }else{
                throw new Error("register error"); 
            }
        })
    })
    }) 
    
}

module.exports = user