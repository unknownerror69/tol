const collection = require('../utilities/connection');
const productData = require('./ProductsDatabase.json');
let product= {}

//Setup the database
product.setupDB = () => {
   return collection.getProductCollection().then( productColl => {
       return productColl.deleteMany().then( data => {
           return productColl.insertMany(productData).then( result => {
               if( result && result.length > 0 ) return result.length
               else return null
           });
       });
   });
}
product.getAllProducts = () => {
    return collection.getProductCollection().then( productColl => {
        return productColl.find().then( data => {
            if(data){
                return data
            }else{
                throw new Error("No products available/cannot find"); 
            }
        })
    }) 
    
}

product.getCategoryProducts = (category) => {
    return collection.getProductCollection().then( productColl => {
        return productColl.find({pCategory:category}).then( data => {
            if(data){
                return data
            }else{
                throw new Error("No products available/cannot find"); 
            }
        })
    }) 
    
}
product.searchedProduct = (searchedData) => {
    return collection.getProductCollection().then(productColl => {
        return productColl.find(
            {$or:[
                {pName:new RegExp(searchedData,'i')},
                {pCategory:new RegExp(searchedData,'i')},
                {specification:new RegExp(searchedData,'i')},
                {color:new RegExp(searchedData,'i')}
            ]}
        ).then(data=>{
            if(data){
                return data
            }else{
                throw new Error("No products available/cannot find"); 
            }
        })
    })
}

module.exports=product;