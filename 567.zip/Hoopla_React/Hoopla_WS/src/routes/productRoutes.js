const express = require("express");
const productRouting = express.Router();
const productService = require('../service/product');



//Setup the database
productRouting.get("/productDBsetup", (req, res, next) => {
    productService.setupDB().then( response =>{
        if(response) res.json({ message : "Successfully inserted "+ response +" documents into productDatabase"})
    }).catch( error =>{
       next(error);
    })
})
productRouting.get('/getAllProducts', (req,res,next)=>{
    
    return productService.getAllProducts().then(productData => {
        res.json(productData);
    }).catch(err => {
        console.log(err.message)
        next(err);
    });
});
productRouting.post('/getCategoryProducts', (req,res,next)=>{
    let category=req.body.pCategory
    console.log(category)
    return productService.getCategoryProducts(category).then(productData => {
        res.json(productData);
    }).catch(err => {
        console.log(err.message)
        next(err);
    });
});
productRouting.post('/getSearchedProducts', (req,res,next)=>{
    let searchedData=req.body.searchProduct
    console.log(searchedData)
    return productService.searchedProduct(searchedData).then(productData => {
        res.json(productData);
    }).catch(err => {
        console.log(err.message)
        next(err);
    });
});
module.exports=productRouting