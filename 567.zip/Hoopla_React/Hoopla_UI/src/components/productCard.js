import React, { Component } from 'react'

export default class ProductCard extends Component {
    constructor(props) {
        super(props);
        
    }
    
    render() {
        return (
            <div style={{padding:"3%"}}>
                <div >
                        <div className="card" style={{width:"250px"}}>
                            <img className="card-image-top" src={`img/${this.props.product.image}`} alt="CardImage" style={{width:"100%",height:"200px"}}/>
                            <div className="card-body bg-light" style={{color:"black"}}>
                                <h6 className="card-title ">{this.props.product.pName}</h6>
                                <p className="card-text text-left">Rating: {this.props.product.pRating}</p>
                                <p className="card-text text-left">Price: ₹ {this.props.product.price}</p>
                                
                            </div>
                        </div>
                    </div>
            </div>
        )
    }
}
