import React, { Component } from 'react';
//import SimpleImageSlider from "react-simple-image-slider";
import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";
import ProductCard from './productCard'
import axios from 'axios'

class Home extends Component {
  constructor(props) {
    super(props)
    this.state={
      // categoryProductArray:[],
      // category:this.props.category,
      // // category:[],
      // search:[]
      productArray:[],
      category:""
      
    }
  }
  
  productCard = () =>{
    console.log(this.state.category)
    if(this.state.category===""){
      axios.get('http://localhost:2000/getAllProducts').then((res)=>{
      console.log(res.data.length)
      this.setState({productArray:res.data})
      console.log(this.state.productArray)
    }).catch((error)=>{
      if(error.response){
        console.log(error.response.data)
      }else{
        console.log(error)
      }
    })
    }  
  }
  componentDidMount(){
    console.log("sam")
    this.productCard()
    
  }
 
  
  render() {
  

    if((this.props.searchPdAr).length!==0){
      let x=(this.props.searchPdAr.map((prod,index)=>{
        return <ProductCard product={prod}/>
      }))
      return <div className="row" style={{justifyContent:"center"}}>{x}</div>
    }else{
    return (
      <React.Fragment>
        
        {/* Slider */}
              {/* <img src={require("../assets/img/clothing.png")} alt="Clothing Pic" />
              <img src={require("../assets/img/furnitures.png")} alt="Furniture Pic" />
              <img src={require("../assets/img/shoes.png")} alt="Shoes Pic" />
              <img src={require("../assets/img/mobiles.png")} alt="Mobiles Pic" /> */}
              
                {this.props.category===""?
                <div >
                
                <div style={{justifyContent:"center",padding:"1%" }}>
                
                <AliceCarousel autoPlay autoPlayInterval="3000" >
                      <img src="img/clothing.png" className="sliderimg" alt="clothing" style={{marginLeft:'25%'}}/>
                      <img src="img/furnitures.png" className="sliderimg" alt="furnitures" style={{marginLeft:'25%'}}/>
                      <img src="img/shoes.png" className="sliderimg" alt="shoes" style={{marginLeft:'25%'}}/>
                      <img src="img/mobiles.png" className="sliderimg" alt="mobiles" style={{marginLeft:'25%'}}/>
                </AliceCarousel>
                </div>
                <div className="row" style={{justifyContent:"center"}}>{this.state.productArray.map((prod,index)=>
                  {return <ProductCard product={prod}/>}
                )}</div>
              </div>:<div className="row" style={{justifyContent:"center"}}>{this.props.categProdArr.map((prod,index)=>{
              return <ProductCard product={prod}/>}
                )}</div>}
                
                
              
      </React.Fragment>
    )}
  }
}

export default Home;