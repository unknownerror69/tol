import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
// import './App.css';
import Navbar from "./NavBar";

import Login from "./Login";
import register from './register';


class App extends Component {

  render() {
    return (
      <div>
        
        <Router>
        {/* <Navbar /> */}
          <Fragment>
          <Route path='/' component={Navbar} />
            <Switch>
              
              <Route exact path='/login' component={Login} />
              <Route exact path='/register' component={register} />
            </Switch>
          </Fragment>
        </Router>
      </div>
    );
  }
}

export default App