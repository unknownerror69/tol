import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import Home from './Home';
import axios from 'axios';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  appbar:{
      allignment:"center"
  },
  tabs:{
      width:"100%",
  }
}));

export default function SimpleTabs(props) {
  const classes = useStyles();
  const [value, setValue] = React.useState();
  const [sel,setSel] =React.useState("")
  const [pdArr,setPdArr]=React.useState([])
  
  //console.log(sessionStorage.getItem('selcat'))
  function categoryCard(category){
      axios.post('http://localhost:2000/getCategoryProducts',{pCategory:category}).then((res)=>{
          console.log(res.data.length)
          setPdArr(res.data)
        }).catch((error)=>{
          if(error.response){
            console.log(error.response.data)
          }else{
            console.log(error)
          }
        })
    }
  const handleChange = (event, newValue) => {
    setValue(newValue);
  }; 
  const handleClick1 = () => {
    console.log("Ele")
    setSel("Electronics")
    categoryCard("Electronics")
  };
  const handleClick2 = () => {
    console.log("SHOE")
    setSel("Shoe")
    categoryCard("Shoes")
  };
  const handleClick3 = () => {
    console.log("fur")
    setSel("Furniture")
    categoryCard("Furniture")
  };
  const handleClick4 = () => {
    console.log("Cloth")
    setSel("Clothing")
    categoryCard("Clothing")
  };
  // if(props.homeClick){
  //   console.log("click")
  //   setPdArr([])
  // }
  useEffect(() => {
    setPdArr([])
    setSel("")
    return () => {
      //
    };
  }, [props.homeClick]);
  return (
    <React.Fragment>
    <div className={classes.root}>
      <AppBar position="static" className={classes.appbar}>
        <Tabs value={value} onChange={handleChange} variant="fullWidth" aria-label="simple tabs example" className={classes.appbar}>
          <Tab label="ELECTRONICS" {...a11yProps(0)} onClick={handleClick1}/>
          <Tab label="SHOES" {...a11yProps(1)} onClick={handleClick2}/>
          <Tab label="FURNITURE" {...a11yProps(2)} onClick={handleClick3}/>
          <Tab label="CLOTHING" {...a11yProps(3)} onClick={handleClick4}/>
        </Tabs>
      </AppBar>
      
    </div>
    <Home category={sel} categProdArr={pdArr} searchPdAr={props.searchPrdArr}/>
    
    </React.Fragment>
  );
}
